from tkinter import *
from PIL import  Image, ImageTk
import subprocess
from sveUsvemu import get_user_by_name,get_user_by_pas

#uništavanjelogin prozora i prikaz biljaka i posuda
def open_new_window():
    root.destroy()
    subprocess.call(['python', 'Biljke.py'])
    

root = Tk()
root.title("Login")
root.geometry("900x500")
root.minsize(600,350)
root.maxsize(1500,900)
root.configure(background="black")
mainColor="#c6d1b2"

def logIN(username, password):
    
    user_from_db = get_user_by_name(username)
    pas_from_db=get_user_by_pas(password)

    if not user_from_db:
        if not pas_from_db:
            passwordEntry["bg"]='#fac8c8'
            passwordLetters["fg"]="#d94162"
            eyeButton["bg"]='#fac8c8'
            eyeButton["activebackground"]='#fac8c8'
            usernameEntry["bg"]='#fac8c8'
            usernameLetters["fg"]="#d94162"
            warningLetters["text"]="Wrong password and username"
            return "wrong"
        else:
            tuple_without_parentheses0 = pas_from_db[0]
            user = list(tuple_without_parentheses0)
            if(user[0]==username):
                usernameEntry["bg"]='white'
                usernameLetters["fg"]="black"
                warningLetters["text"]=""
            else:
                usernameEntry["bg"]='#fac8c8'
                usernameLetters["fg"]="#d94162"
            if(user[1]==password):
                passwordEntry["bg"]='white'
                passwordLetters["fg"]="black"
                eyeButton["bg"]='white'
                eyeButton["activebackground"]='white'
                warningLetters["text"]=""
                if(user[0]!=username):
                    warningLetters["text"]="Wrong username"
            else:
                passwordEntry["bg"]='#fac8c8'
                passwordLetters["fg"]="#d94162"
                eyeButton["bg"]='#fac8c8'
                eyeButton["activebackground"]='#fac8c8'
                warningLetters["text"]="Wrong password"

            if(user[0]==username and user[1]==password):
                open_new_window()
    else:
        tuple_without_parentheses1 = user_from_db[0]
        user = list(tuple_without_parentheses1)  

        if(user[0]==username):
            usernameEntry["bg"]='white'
            usernameLetters["fg"]="black"
            warningLetters["text"]=""
        else:
            usernameEntry["bg"]='#fac8c8'
            usernameLetters["fg"]="#d94162"
        if(user[1]==password):
            passwordEntry["bg"]='white'
            passwordLetters["fg"]="black"
            eyeButton["bg"]='white'
            eyeButton["activebackground"]='white'
            warningLetters["text"]=""
            if(user[0]!=username):
                warningLetters["text"]="Wrong username"
        else:
            passwordEntry["bg"]='#fac8c8'
            passwordLetters["fg"]="#d94162"
            eyeButton["bg"]='#fac8c8'
            eyeButton["activebackground"]='#fac8c8'
            warningLetters["text"]="Wrong password"

        if(user[0]==username and user[1]==password):
            open_new_window()

    

vision=PhotoImage(file='images/vision2.png')
heading=PhotoImage(file="images/Logo.png")

#hover login gumba
def bttn(img1,img2):
        ImageB=ImageTk.PhotoImage(Image.open(img1))
        ImageA=ImageTk.PhotoImage(Image.open(img2))

        def on_Enter(e):
            myButton['image']=ImageB

        def on_leave(e):
            myButton['image']=ImageA

        myButton=Button(root,image=ImageA,border=0,bg=mainColor,activebackground=mainColor,cursor="hand2",width=220,height=35,command=lambda:[logIN(usernameEntry.get(),passwordEntry.get())])

        myButton.bind("<Enter>",on_Enter)
        myButton.bind("<Leave>",on_leave)

        myButton.place(relx = 0.5,rely = 0.73,anchor = 'center')

#prikaz AAA ili ***
def hide():
    vision.config(file='images/vision2.png')
    passwordEntry.config(show="*")
    eyeButton.config(command=show)

def show():
    vision.config(file='images/blind3.png')
    passwordEntry.config(show="")
    eyeButton.config(command=hide)

# pošto ovaj ekran nije fiksan, ova klasa uveličava ili smanjuje pozadinsku sliku
class Example(Frame):
    def __init__(self, master, *pargs):
        Frame.__init__(self, master, *pargs)

        self.image = Image.open('images/0.png')
        self.img_copy= self.image.copy()

        self.background_image = ImageTk.PhotoImage(self.image)

        self.background = Label(self, image=self.background_image)
        self.background.pack(fill=BOTH, expand=YES)
        self.background.bind('<Configure>', self._resize_image)


    def _resize_image(self,event):
        new_width = event.width
        new_height = event.height

        self.image = self.img_copy.resize((new_width, new_height))

        self.background_image = ImageTk.PhotoImage(self.image)
        self.background.configure(image =  self.background_image)
    
e = Example(root)
e.pack(fill=BOTH, expand=YES)

mainFrame=Frame(root,width=400,height=1000,bg=mainColor).place(relx = 0.5,rely = 0.5,anchor = 'center')

logoButon=Label(mainFrame,image=heading,width=400,height=550,bg=mainColor).place(relx = 0.5,rely = 0.12,anchor = 'center')

headingLetters=Label(root,text="PyFloraPosude",font=('Verdana',15),bg="#93BF46",fg="Black")
headingLetters.place(relx = 0.5,rely = 0.12,anchor = 'center')

usernameLetters=Label(root,text="Username:",font=('Verdana',15),bg=mainColor,fg="black")
usernameLetters.place(relx = 0.5,rely = 0.31,anchor = 'center')

usernameEntry=Entry(root,width=20,font=('Verdana',15),bg="white")
usernameEntry.place(relx = 0.5,rely = 0.4,anchor = 'center')

passwordLetters=Label(root,text="Password:",font=('Verdana',15),bg=mainColor,fg="black")
passwordLetters.place(relx = 0.5,rely = 0.51,anchor = 'center')

passwordEntry=Entry(root,width=20,font=('Verdana',15),bg="white",show="*")
passwordEntry.place(relx = 0.5,rely = 0.6,anchor = 'center')

eyeButton=Button(passwordEntry,image=vision,bd=0,bg="white",activebackground="white",cursor="hand2",command=show)
eyeButton.place(relx = 0.90,rely = 0.50,anchor = 'w')

warningLetters=Label(root,text="",font=('Verdana',15),bg=mainColor,fg="#d94162")
warningLetters.place(relx = 0.5,rely = 0.9,anchor = 'center')

bttn("images/onHovered.png","images/Buton.png")

root.mainloop()