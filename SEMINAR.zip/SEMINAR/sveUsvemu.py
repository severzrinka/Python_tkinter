import sqlite3
"""
# create a new SQLite database
conn = sqlite3.connect('PyFloraPosude.db')

# create a new table called "plants" and insert some sample data
conn.execute('''CREATE TABLE plants
             (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ime TEXT, pic TEXT,tlo TEXT,svjetlo TEXT,temperatura TEXT,kompost TEXT)''')

plants_data = [
    (1, 'Jezik', 'images/jezik.png', 'tjedno', 'svjetla', 'toplija', 'Pijesak'),
    (2, 'Paprat', 'images/paprat.png', 'tjedno', 'svjetla', 'hladnija', 'Pijesak'), 
    (3, 'areka palma', 'images/areka palma.png', 'dnevno', 'svjetla', 'hladnija' ,'Treset'), 
    (4, 'citrus', 'images/citrus.png', 'dnevno', 'svjetla', 'toplija', 'Vermikulit'), 
    (5, 'monstera', 'images/monstera.png', 'mjesečno', 'tamna', 'toplija', 'Perlit'),
    (6, 'Aloa Vera', 'images/vera.png', 'mjesečno', 'svjetla', 'hladnija', 'Kokosova vlakna'), 
    (7, 'Bršljan', 'images/brsljan.png', 'dnevno', 'svjetla', 'toplija', 'Vermikulit'),
    (8, 'rajska ptica', 'images/ptica.png', 'dnevno', 'svjetla', 'toplija', 'Treset'),
    (9, 'šeflera', 'images/seflera.png', 'mjesečno', 'tamna', 'hladnija', 'Pijesak'),
    (10, 'fikus', 'images/fikus.png', 'mjesečno', 'tamna', 'hladnija', 'Perlit'),
    (11, 'dodaj biljku', 'images/Nono.png', None, None, None, None),
]

conn.executemany('INSERT INTO plants (id, ime, pic, tlo, svjetlo, temperatura, kompost) VALUES (?, ?, ?, ?, ?, ?, ?)', plants_data) #7


# create a new table called "posude" and insert some sample data
conn.execute('''CREATE TABLE posude
             (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, place TEXT, Plantname TEXT,plantId INTEGER,soil TEXT,ph INTEGER,salt INTEGER,light INTEGER,temperatura INTEGER)''')
posude_data = [(1, 'soba', 'Aloa Vera',6,'suha',7,0,1,20), 
(2, 'hodnik', 'Bršljan',7,'normalna',10,1,1,20), 
(3, 'hodnik', 'Jezik',1,'mokra',12,0,0,20), 
(4, 'balkon', 'Paprat',2,'suha',8,1,0,20), 
(5, 'kupaona', '',None,None,None,None,None,None)]
conn.executemany('INSERT INTO posude (id, place, Plantname,plantId,soil,ph,salt,light,temperatura ) VALUES (?, ?, ?,?,?,?,?,?,?)', posude_data)#9




# create a new table called "senzori" and insert some sample data
conn.execute('''CREATE TABLE senzori
             (posudaId INTEGER,voda INTEGER, ph INTEGER, sol INTEGER, light INTEGER)''')
senzori_data = []
conn.executemany('INSERT INTO senzori (posudaId,voda,ph,sol,light ) VALUES (?,?, ?, ?,?)', senzori_data)



conn.execute('''CREATE TABLE User(
     username varchar,
     pas varchar
 )''')
user_data=[("Domagoj", "test")]
conn.executemany('INSERT INTO User (username,pas) VALUES (?, ?)', user_data)

# commit the changes and close the connection
conn.commit()
conn.close()
"""
# Connect to the database POSUDE
conn = sqlite3.connect('PyFloraPosude.db')
c = conn.cursor()


def insert_posuda(place, name,idBiljke,soil,ph,salt,light,temperatura):
    with conn:
        c.execute('INSERT INTO posude (place, Plantname,plantId,soil,ph,salt,light,temperatura) VALUES (?, ?,?,?,?,?,?,?)', (place, name,idBiljke,soil,ph,salt,light,temperatura))
        id = c.lastrowid
        return id

def update_posuda(name, place,idBiljke, soil,ph,salt,light,temperatura,id):
    with conn:
        c.execute('UPDATE posude SET Plantname=?, place=?,plantId=?,soil=?,ph=?,salt=?,light=?,temperatura=? WHERE id=?', (name, place,idBiljke,soil,ph,salt,light,temperatura, id))

def delete_posuda(id):
    with conn:
        c.execute('DELETE FROM posude WHERE id=?', (id,))

def get_posuda_by_all():
    c.execute("SELECT * FROM posude")
    result = c.fetchall()
    return result

def get_posuda_by_id(id):
    c.execute("SELECT * FROM posude WHERE id=?",(id,))
    result = c.fetchall()
    return result

def get_posuda_by_id_indeks(id,indeks):
    c.execute("SELECT * FROM posude WHERE id=?",(id,))
    result = c.fetchall()[indeks]
    return result

def row_count_Posude():
    c.execute('SELECT COUNT(*) FROM posude')
    result =c.fetchone()[0]
    return result


#-------------------------------------------------------------------------------------------------------------------------------------------------
#tlo TEXT,svjetlo TEXT,temperatura TEXT,kompost TEXT BILJKE
def insert_plant(name, photo,tlo,svjetlo,temperatura,kompost):
    with conn:
        c.execute('INSERT INTO plants (ime, pic,tlo,svjetlo,temperatura,kompost) VALUES (?, ?,?,?,?,?)', (name, photo,tlo,svjetlo,temperatura,kompost))
        plant_id = c.lastrowid
        return plant_id


def update_plant(new_name, new_photo,tlo,svjetlo,temperatura,kompost, id):
    with conn:
        c.execute('UPDATE plants SET ime=?, pic=?,tlo=?,svjetlo=?,temperatura=?,kompost=? WHERE id=?', (new_name, new_photo,tlo,svjetlo,temperatura,kompost,id))
    
def delete_plant(id):
    with conn:
        c.execute('DELETE FROM plants WHERE id=?', (id,))

def get_plant_by_all():
    c.execute("SELECT * FROM plants")
    result = c.fetchall()
    return result

def get_plant_by_ime_pic(ime, pic):
    conn = sqlite3.connect('PyFloraPosude.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM plants WHERE ime=? and pic=?", (ime, pic))
    result = cursor.fetchall()
    conn.close()
    return result

def get_plant_by_id(id):
    c.execute('SELECT * FROM plants WHERE id=?', (id,))
    result = c.fetchall()
    return result

def get_plant_by_id_indeks(id,indeks):
    c.execute("SELECT * FROM plants WHERE id=?",(id,))
    result = c.fetchall()[indeks]
    return result

def row_count_Plant():
    c.execute('SELECT COUNT(*) FROM plants')
    result =c.fetchone()[0]
    return result

#-------------------------------------------------------------------------------------------------------------------------------------------------
# SENZORI  (posudaId INTEGER,voda INTEGER, ph INTEGER, sol INTEGER, light INTEGER

def insert_senzor(posudaId, voda,ph,sol,light):
    with conn:
        c.execute("INSERT INTO senzori VALUES(?,?,?,?,?)", (posudaId,voda,ph,sol,light))

def delete_senzor():
    with conn:
        c.execute("DELETE FROM senzori;")

def get_senzori_by_all():
    c.execute("SELECT * FROM senzori")
    result = c.fetchall()
    return result

#-------------------------------------------------------------------------------------------------------------------------------------------------
# LOGIN

class User:

    def __init__(self, username, pas):
        self.username = username
        self.pas = pas

    def __repr__(self):
        return "User('{}', {})".format(self.username, self.pas)

def insert_use(use):
    with conn:
        c.execute("INSERT INTO User VALUES(?,?)", (use.username,use.pas))

def get_user_by_name(username):
    c.execute("SELECT * FROM User WHERE username=?",(username,))
    return c.fetchall()

def get_user_by_all():
    c.execute("SELECT * FROM User")
    result = c.fetchall()
    return result

def get_user_by_pas(pas):
    c.execute("SELECT * FROM User WHERE pas=?",(pas,))
    return c.fetchall()

def remove_use(use):
    with conn:
        c.execute('''DELETE from User WHERE username=? AND pas=?''',(use.username,use.pas))

delete_senzor()
print(get_user_by_all())
#print(get_plant_by_all())
# print(len(get_plant_by_all()))
#print(get_posuda_by_all())
