import sqlite3
import datetime
import random
import requests
from bs4 import BeautifulSoup

def update_posuda_randomly(id):
    api_key = "f545d51eec0f426cb4d171146232304"

    url = "http://api.weatherapi.com/v1/current.json"
    params = {"key": api_key, "q": "Zagreb"}

    response = requests.get(url, params=params)

    if response.status_code == 200:
        data = response.json()
        
        temperature = data["current"]["temp_c"]
        
    else:
        url = "https://vrijeme.hr/hrvatska_n.xml"

        response = requests.get(url)

        soup = BeautifulSoup(response.text, "lxml-xml")


        zagreb_data = soup.find("GradIme", string="Zagreb-Maksimir").parent

        temperature = zagreb_data.find("Temp").text.strip()


    conn = sqlite3.connect('PyFloraPosude.db')
    c = conn.cursor()
    soil_options = ['mokra', 'suha', 'normalna']
    ph_options = list(range(0, 15))
    salt_options = [0, 1]
    light_options = [0, 1]
    temperatura =int(temperature)

    new_soil = random.choice(soil_options)
    new_ph = random.choice(ph_options)
    new_salt = random.choice(salt_options)
    new_light = random.choice(light_options)

    with conn:
        c.execute('UPDATE posude SET soil=?,ph=?,salt=?,light=?,temperatura=? WHERE id=?', (new_soil, new_ph, new_salt, new_light, temperatura, id))
    conn.close()
    