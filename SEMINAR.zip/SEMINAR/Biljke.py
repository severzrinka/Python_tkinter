from tkinter import *
from PIL import  Image, ImageTk,ImageDraw,ImageOps
from  APlant import APlant
import re
from SyncMaster import update_posuda_randomly
from sveUsvemu import User, get_user_by_name,get_user_by_pas,remove_use,insert_use,get_posuda_by_id,insert_plant,update_plant,delete_plant,get_posuda_by_all,get_plant_by_all,get_plant_by_id,get_plant_by_id_indeks,row_count_Plant,row_count_Posude,update_posuda,insert_posuda,delete_posuda,insert_senzor,get_senzori_by_all,delete_senzor

root = Tk()
root.title("Biljke")

#klasa koja uzima točne podatke iz sql-a i definira informacije sa senzora

class PlantManager:
    def __init__(self):
        self.listaBiljaka=[]
        self.posude=[]
        self.matching_plants = []
        self.indexOfPlants=0
        self.vrijednostiposuda=[]
        self.vrijednostibiljka=[]
        self.rezultatStatusa=[]

    def updateAposuda(self):
        self.listaBiljaka=get_plant_by_all()
        self.posude=get_posuda_by_all()
        self.matching_plants = []
        self.vrijednostiposuda=[]
        self.vrijednostibiljka=[]
        self.rezultatStatusa=[]
        for posuda in self.posude:
            self.vrijednostiposuda.append((posuda[4],posuda[5],posuda[6],posuda[7],posuda[8]))
            for biljka in self.listaBiljaka:
                if posuda[3] == biljka[0]:
                    self.matching_plants.append((biljka[0], biljka[1], biljka[2],posuda[0],biljka[3],biljka[4],biljka[5],biljka[6]))
                    self.vrijednostibiljka.append((biljka[3],biljka[4],biljka[5],biljka[6]))
            if posuda[3] == None:
                self.matching_plants.append((None,"prazna posuda","images/Nono.png",posuda[0]))
        self.vrijednostiposuda=self.vrijednostiposuda[:-1]
        for i in range(len(self.vrijednostiposuda)):
            if self.vrijednostiposuda[i][0]=="suha":
                if self.vrijednostibiljka[i][0]=="dnevno":
                    self.rezultatStatusa.append("dodajte vode")
                if self.vrijednostibiljka[i][0]=="tjedno":
                    self.rezultatStatusa.append("dodajte vode")
                if self.vrijednostibiljka[i][0]=="mjesečno":
                    self.rezultatStatusa.append("ok")
            if self.vrijednostiposuda[i][0]=="mokra":
                if self.vrijednostibiljka[i][0]=="dnevno":
                    self.rezultatStatusa.append("ok")
                if self.vrijednostibiljka[i][0]=="tjedno":
                    self.rezultatStatusa.append("prevlažno tlo")
                if self.vrijednostibiljka[i][0]=="mjesečno":
                    self.rezultatStatusa.append("prevlažno tlo")
            if self.vrijednostiposuda[i][0]=="normalna":
                    self.rezultatStatusa.append("ok")
            if self.vrijednostiposuda[i][1]>=6 and self.vrijednostiposuda[i][1]<=8:
                self.rezultatStatusa.append("ok")
            if self.vrijednostiposuda[i][1]<6:
                self.rezultatStatusa.append("kiseli ph zemlje,\ndodajte supstrat")
            if self.vrijednostiposuda[i][1]>8:
                self.rezultatStatusa.append("lužnati ph zemlje,\ndodajte supstrat")
            
            if self.vrijednostiposuda[i][2]==0:
                self.rezultatStatusa.append("ok")
            else:
                self.rezultatStatusa.append("salinitet zemlje visok,\ndodajte supstrat")
            if self.vrijednostiposuda[i][3]==0:
                if self.vrijednostibiljka[i][1]=="tamna":
                     self.rezultatStatusa.append("ok")
                else:
                    self.rezultatStatusa.append("biljka treba svjetla")
            else:
                if self.vrijednostibiljka[i][1]=="tamna":
                     self.rezultatStatusa.append("biljka treba \nmanje svjetla")
                else:
                    self.rezultatStatusa.append("ok")
        self.rezultatStatusa = [(self.rezultatStatusa[i], self.rezultatStatusa[i+1], self.rezultatStatusa[i+2], self.rezultatStatusa[i+3]) for i in range(0, len(self.rezultatStatusa), 4)]

plant_manager = PlantManager()

plant_manager.updateAposuda()

screen_width = 1500
screen_height = 900
root.minsize(screen_width, screen_height)
root.maxsize(screen_width, screen_height)
bakColor="#f0f7e4"
root.configure(background=bakColor)
mainColor="#92ad5f"

#ova funkcija upravlja prikaza na ekranu, da li gledamo biljke ili posude. Koristim je kao refresh
def toggle_switch():
    if switch['image'] == "pyimage6":
        switch.configure(image="pyimage7")
        gumbi=[]
        for image in range(len(plant_manager.listaBiljaka)):
            gumbi.append(plant_manager.listaBiljaka[image][2])
        stosegleda["text"]="BILJKE"
        update_grid(gumbi,plant_manager.listaBiljaka)
    else:
        switch.configure(image="pyimage6")
        gumbi=[]
        for image in range(len(plant_manager.matching_plants)):
            gumbi.append(plant_manager.matching_plants[image][2])
        stosegleda["text"]="POSUDE"
        update_grid(gumbi,plant_manager.matching_plants)

heading=PhotoImage(file="images/PyFloraPosude.png")
settings=PhotoImage(file="images/settings.png")
sync=PhotoImage(file="images/sync.png")
next=PhotoImage(file="images/next.png")
previous=PhotoImage(file="images/previous.png")
switchPosude = ImageTk.PhotoImage(Image.open("images/switchPosude.png"))
switchBiljke = ImageTk.PhotoImage(Image.open("images/switchBiljke.png"))

okvir = Image.open("images/frame.png")
trueOkvir = ImageTk.PhotoImage(okvir)
visionOld=PhotoImage(file='images/vision2.png')
visionNew=PhotoImage(file='images/vision2.png')
gumbi=[]

for image in range(row_count_Posude()):
    gumbi.append(plant_manager.matching_plants[image][2])

#gumb za podatke sa senzora
def syncClick(): 
    for i in get_posuda_by_all():
        if i[3]!=None:
            update_posuda_randomly(i[0])


            data = i[4:8]

            if data[0] == "suha":
                data = (0, *data[1:])
            elif data[0] == "normalna":
                data = (1, *data[1:])
            elif data[0] == "mokra":
                data = (2, *data[1:])

            insert_senzor(i[0],data[0],data[1],data[2],data[3])
    
            
    plant_manager.updateAposuda()
    toggle_switch()
    toggle_switch()

#popup koji otvara polje za promjenu sifre i username-a
def openChange():
    pasOld["bg"]='white'
    pasOld.delete(0, END)
    pasNew.delete(0, END)
    oldPas["fg"]="black"
    usernameOld["bg"]='white'
    usernameOld.delete(0, END)
    usernameNew.delete(0, END)
    oldLetters["fg"]="black"
    eyeButtonOld["bg"]='white'
    warningLetters["text"]=""
    eyeButtonOld["activebackground"]='white'
    if changeLogin.winfo_ismapped():
        changeLogin.place_forget()
        switch.place(relx=0.7, rely=0.5, anchor='w')
    else:
        changeLogin.place(relx=0.57, rely=0.309, anchor='w')
        switch.place_forget()


def on_configure(event):
         if changeLogin.winfo_ismapped():
            changeLogin.place_forget()
            changeLogin.place(relx=0.57, rely=0.309, anchor='w')
         else:
             return

root.bind("<Configure>", on_configure)

#promjena šifre i username-a
def loginCheck(username, password,newUsername,newPassword):
    
    user_from_db = get_user_by_name(username)
    pas_from_db=get_user_by_pas(password)


    if not user_from_db:
        if not pas_from_db:
            pasOld["bg"]='#fac8c8'
            oldPas["fg"]="#d94162"
            eyeButtonOld["bg"]='#fac8c8'
            eyeButtonOld["activebackground"]='#fac8c8'
            usernameOld["bg"]='#fac8c8'
            oldLetters["fg"]="#d94162"
            warningLetters["text"]="Wrong password and username"
        else:
            tuple_without_parentheses0 = pas_from_db[0]
            user = list(tuple_without_parentheses0)
            if(user[0]==username):
                usernameOld["bg"]='#beffb0'
                oldLetters["fg"]="#6c8046"
                warningLetters["text"]=""
            else:
                usernameOld["bg"]='#fac8c8'
                oldLetters["fg"]="#d94162"
            if(user[1]==password):
                pasOld["bg"]='#beffb0'
                oldPas["fg"]="#6c8046"
                eyeButtonOld["bg"]='#beffb0'
                eyeButtonOld["activebackground"]='#beffb0'
                warningLetters["text"]=""
                if(user[0]!=username):
                    warningLetters["text"]="Wrong username"
            else:
                pasOld["bg"]='#fac8c8'
                oldPas["fg"]="#d94162"
                eyeButtonOld["bg"]='#fac8c8'
                eyeButtonOld["activebackground"]='#fac8c8'
                warningLetters["text"]="Wrong password"

            if(user[0]==username and user[1]==password):
                if(usernameNew.get()!=usernameOld.get() and pasNew.get()!=pasOld.get()):
                    insert_use(User(newUsername,newPassword))
                    remove_use(User(username,password))
                    print(newUsername,newPassword)
                    warningLetters["text"]="Uspješno promjenjene informacije!"
                    frameSredina.place_forget()
                else:
                    warningLetters["font"]=12
                    warningLetters["text"]="Stare informacije ne smiju biti iste novim. Ne koristite slova č,ć!"

    else:
        tuple_without_parentheses1 = user_from_db[0]
        user = list(tuple_without_parentheses1)  

        if(user[0]==username):
            usernameOld["bg"]='#beffb0'
            oldLetters["fg"]="#6c8046"
            warningLetters["text"]=""
        else:
            usernameOld["bg"]='#fac8c8'
            oldLetters["fg"]="#d94162"
        if(user[1]==password):
            pasOld["bg"]='#beffb0'
            oldPas["fg"]="#6c8046"
            eyeButtonOld["bg"]='#beffb0'
            eyeButtonOld["activebackground"]='#beffb0'
            warningLetters["text"]=""
            if(user[0]!=username):
                warningLetters["text"]="Wrong username"
        else:
            pasOld["bg"]='#fac8c8'
            oldPas["fg"]="#d94162"
            eyeButtonOld["bg"]='#fac8c8'
            eyeButtonOld["activebackground"]='#fac8c8'
            warningLetters["text"]="Wrong password"

        if(user[0]==username and user[1]==password):
                if(usernameNew.get()!=usernameOld.get() and pasNew.get()!=pasOld.get()):
                    insert_use(User(newUsername,newPassword))
                    remove_use(User(username,password))
                    print(newUsername,newPassword)
                    warningLetters["text"]="Uspješno promjenjene informacije!"
                else:
                    warningLetters["text"]="Stare informacije ne smiju biti iste novim. Ne koristite slova č,ć!"


#fukncije za zvjezdice ili slova za šifre
def hideOld():
    visionOld.config(file='images/vision2.png')
    pasOld.config(show="*")
    eyeButtonOld.config(command=showOld)

def showOld():
    visionOld.config(file='images/blind3.png')
    pasOld.config(show="")
    eyeButtonOld.config(command=hideOld)

def hideNew():
    visionNew.config(file='images/vision2.png')
    pasNew.config(show="*")
    eyeButtonNew.config(command=showNew)

def showNew():
    visionNew.config(file='images/blind3.png')
    pasNew.config(show="")
    eyeButtonNew.config(command=hideNew)


# ova funkcija definira što se prikazuje u APlant.py- podatci o biljci ili o posudi
def show_info(index,gumbi,stoSegleda,status_photo,text_status):
    grafdata=[]
    for i in get_senzori_by_all():
        if i[0]==stoSegleda[index][3]:
            grafdata.append(i)
    #slika statusa
    slikaStatusa = status_photo
    #sam status
    statusA = text_status
    #Slika Biljke
    biljkeSlika=gumbi[index]
    #ime Biljke
    plantName=stoSegleda[index][1]
    #duzina
    length=row_count_Plant()
    #biljke ili posude, zato sam varijablu nazvala ili
    ili=stoSegleda[index]
    #graph data
    grafdata=grafdata
    
    open_aplant_window(slikaStatusa, statusA,biljkeSlika,plantName,index,length,ili,grafdata)

# ova funkcija otvori Aplant.py
def open_aplant_window(slikaStatusa, statusA,biljkeSlika,plantName,index,length,ili,grafdata):
    root.withdraw()

    aplant_window = Toplevel(root)
    screen_width = 1700
    screen_height = 900

    aplant_window.minsize(screen_width, screen_height)
    aplant_window.maxsize(screen_width, screen_height)
    aplant_window.title("APlant")


    aplant = APlant(aplant_window, slikaStatusa, statusA, biljkeSlika,plantName,update_gumbi,update_Plant,insert_plant,
                    row_count_Plant,index,length,ili,grafdata,update_posuda,get_posuda_by_id,terminator,get_plant_by_all,get_posuda_by_all,
                    get_plant_by_id,swipeIt,stosegleda.cget("text"))
    aplant.natragButon.config(command=lambda: (aplant_window.destroy(), root.deiconify()))
    aplant_window.protocol("WM_DELETE_WINDOW", lambda: (aplant_window.destroy(), root.destroy()))


#Funkcija koja se zove iz APlant.py, update biljke sa svim promjenjenim infomacijama
def update_gumbi(index,noviId,identifier,biljka,filename,tlo,svjetlo,temperatura,kompost):

    if noviId!=[] and identifier==None:
        identifier=noviId[0]
    if(svjetlo==True):
        light="svjetla"
    else:
        light="tamna"
    if(temperatura==True):
        toplina="toplija"
    else:
        toplina="hladnija"

    print("biljka prije ",get_plant_by_id(identifier))
    print(filename)
    if identifier!=None:
        update_plant(biljka.cget("text"), filename,tlo,light,toplina,kompost,identifier)
    else:
        update_plant(biljka.cget("text"), filename,tlo,light,toplina,kompost,len(get_plant_by_all())-1)
    

    print("biljka poslje ",get_plant_by_id(identifier))

    plant_manager.updateAposuda()
    toggle_switch()
    toggle_switch()

#Funkcija koja se zove iz APlant.py, brišem ili posudu ili biljku
def terminator(id,sto):

    for record in get_posuda_by_all():
        if(get_plant_by_id(id)[0][0]==record[3]):
            delete_plant(id)
            delete_posuda(record[0])
            plant_manager.updateAposuda()
            toggle_switch()
            toggle_switch()
            return
    print(sto)
    if len(sto)==8:
        delete_posuda(id)
    else:
        delete_plant(id)

    plant_manager.updateAposuda()  
    print("poslje BRISANJA ",get_posuda_by_id(id))
    toggle_switch()
    toggle_switch()


#Funkcija koja se zove iz APlant.py, dodajem već postojanu biljku u praznu posudu ili zamjenim biljku u posudi sa biljkom u listi biljaka
def swipeIt(imeuposudi,mjestobiljke,biljkauposudi,selektiranabiljka):
    imebiljke =re.sub('[^a-zA-Z]+', '', selektiranabiljka)
    selektiranabiljka = re.sub(r'[^0-9]', '', selektiranabiljka)
    if imeuposudi!="prazna posuda":
        #(name, place,idBiljke, soil,ph,salt,light,temperatura,id):
        update_posuda(imebiljke,mjestobiljke,selektiranabiljka,'suha',8,1,0,20,biljkauposudi[3])
        update_posuda_randomly(selektiranabiljka)
        plant_manager.updateAposuda()
        toggle_switch()
        toggle_switch()
    else:
        update_posuda(imebiljke,mjestobiljke,selektiranabiljka,'suha',8,1,0,20,biljkauposudi[3])
        insert_posuda("", "prazna posuda",None,None,None,None,None,None)
        plant_manager.updateAposuda()
        toggle_switch()
        toggle_switch()
        

#Funkcija koja se zove iz APlant.py, Tu mjenjam informacije o potrebi biljke u posudi i same biljke
def update_Plant(nova,slika,noviId,place,indentifier,x,y,z,m):
    if(y==True):
        light="svjetla"
    else:
        light="tamna"
    if(z==True):
        toplina="toplija"
    else:
        toplina="hladnija"
    if stosegleda.cget("text")!="BILJKE":
        update_plant(nova, slika,x,light,toplina,m,len(get_plant_by_all()))
        update_posuda(nova,place,len(get_plant_by_all()),None,None,None,None,None,indentifier)
        update_posuda_randomly(indentifier)
        insert_plant('dodaj biljku', 'images/Nono.png', None, None, None, None)
        insert_posuda("", "prazna posuda",None,None,None,None,None,None)
    else:
        update_plant(nova, slika,x,light,toplina,m,len(get_plant_by_all()))
        insert_plant('dodaj biljku', 'images/Nono.png', None, None, None, None)

    print(get_posuda_by_all())
    print(get_plant_by_all())

    plant_manager.updateAposuda()
    toggle_switch()
    toggle_switch()


#glavna funkcija koja prikazuje grid sa biljkama ili sa posudama    
def update_grid(gumbi,stoSegleda):
    for widget in buttonFrame.winfo_children():
        widget.destroy()
    
    stoSegleda=stoSegleda

    num_rows = len(gumbi)//2 + len(gumbi)%2
    broj=2
    for i in range(num_rows):
        for j in range(broj):
            index = i*2 + j
            if index >= len(gumbi):
                break
            image = Image.open(gumbi[index])
            image = image.resize((300, 300), Image.LANCZOS)
            mask = Image.new("L", (300, 300), 0)
            draw = ImageDraw.Draw(mask)
            radius = 30
            draw.pieslice([(0,0), (2*radius, 2*radius)], 180, 270, fill=255)
            draw.pieslice([(0,300-2*radius), (2*radius, 300)], 90, 180, fill=255)
            draw.pieslice([(300-2*radius, 0), (300, 2*radius)], 270, 360, fill=255)
            draw.pieslice([(300-2*radius, 300-2*radius), (300, 300)], 0, 90, fill=255)
            draw.rectangle([(radius, 0), (300-radius, 300)], fill=255)
            draw.rectangle([(0, radius), (300, 300-radius)], fill=255)
            image.putalpha(mask)
            #definiranje prikaza posuda!
            if len(stoSegleda[index]) in [4, 8]:
                viseSlika = Image.open("images/gridInfo.jpg")
                slika = ImageTk.PhotoImage(viseSlika)
                photo = ImageTk.PhotoImage(image)
                button_images.append(photo)
                frame = Label(buttonFrame,bg=mainColor,image=trueOkvir,width=700, height=400)
                frame.grid(row=i, column=j, padx=10, pady=10)
                if len(stoSegleda[index])==4:
                    button = Button(buttonFrame, image=photo,bd=0, text=f"Button {i*broj+j+1}", bg=mainColor, activebackground=mainColor, fg="#f0f7e4", width=300, height=300,command=lambda index=i*broj+j: show_info(index,gumbi,stoSegleda,"",""))
                    imeBiljke = Label(buttonFrame, text=stoSegleda[i*broj+j][1], font=('Verdana', 15), bg="#F1DBEB", fg="Black")
                    imeBiljke.grid(row=i, column=j, sticky="N", padx=0.5, pady=15)
                    viseInfo = Button(buttonFrame, image=slika, bg=mainColor, activebackground=mainColor,cursor="hand2", fg="#f0f7e4",command=lambda index=i*broj+j: show_info(index,gumbi,stoSegleda,"",""))
                    viseInfo.image = slika
                    viseInfo.grid(row=i, column=j, sticky="se", padx=30, pady=20)
                else:
                    imeBiljke = Label(buttonFrame, text=stoSegleda[i*broj+j][1], font=('Verdana', 15), bg="#F1DBEB", fg="Black")
                    imeBiljke.grid(row=i, column=j, sticky="N", padx=0.5, pady=15)
                    button = Button(buttonFrame, image=photo,bd=0, text=f"Button {i*broj+j+1}", bg=mainColor, activebackground=mainColor, fg="#f0f7e4", width=300, height=300,command=lambda index=i*broj+j: show_info(index,gumbi,stoSegleda,status_photo,text_status))
                button.image = photo
                button.grid(row=i, column=j, sticky="W", padx=15)
                if index >= len(plant_manager.rezultatStatusa):
                    break
                status_text = plant_manager.rezultatStatusa[index]
                text_status=[]
                for what in status_text:
                    if what!='ok':
                        text_status.append(what)
                text_status="\n".join(text_status)
                if 'salinitet zemlje visok,\ndodajte supstrat' in status_text or 'lužnati ph zemlje,\ndodajte supstrat' in status_text or 'kiseli ph zemlje,\ndodajte supstrat'in status_text:
                    status_image = Image.open(status_images['salinitet zemlje visok,\ndodajte supstrat'])
                elif 'dodajte vode' in status_text or 'prevlažno tlo' in status_text or 'biljka treba \nmanje svjetla' in status_text or 'biljka treba svjetla' in status_text:
                    status_image = Image.open(status_images['prevlažno tlo'])
                else:
                    status_image = Image.open(status_images['ok'])
                    text_status ='ok'
                status_photo = ImageTk.PhotoImage(status_image)
                slikaStatus = Label(buttonFrame, image=status_photo,bg=mainColor,fg="#f0f7e4", width=100, height=100)
                slikaStatus.image = status_photo
                slikaStatus.grid(row=i, column=j, sticky="e", padx=85, pady=25)
                status = Label(buttonFrame, text=text_status, font=('Verdana', 13), bg=mainColor, fg="White")
                status.grid(row=i, column=j, sticky="e", padx=200, pady=10)
                status_photo = ImageTk.PhotoImage(status_image)
                viseInfo = Button(buttonFrame, image=slika, bg=mainColor, activebackground=mainColor,cursor="hand2", fg="#f0f7e4",command=lambda index=i*broj+j: show_info(index,gumbi,stoSegleda,status_photo,text_status))
                viseInfo.image = slika
                viseInfo.grid(row=i, column=j, sticky="se", padx=30, pady=20)
            #definiranje prikaza biljaka
            if len(stoSegleda[index])==7:
                if stoSegleda[index][3]!=None:
                    text_status = "Potrebe zaljevanja:"+stoSegleda[index][3]+"\npotrebe svjetla: "+stoSegleda[index][4]+"\nmjesto: "+stoSegleda[index][5]+"\nsupstrat : "+stoSegleda[index][6]
                else:
                    text_status =""
                viseSlika = Image.open("images/gridInfo.jpg")
                slika = ImageTk.PhotoImage(viseSlika)
                photo = ImageTk.PhotoImage(image)
                button_images.append(photo)
                frame = Label(buttonFrame,bg=mainColor,image=trueOkvir,width=700, height=400)
                frame.grid(row=i, column=j, padx=10, pady=10)
                button = Button(buttonFrame, image=photo,bd=0, text=f"Button {i*broj+j+1}", bg=mainColor, activebackground=mainColor, fg="#f0f7e4", width=300, height=300,command=lambda index=i*broj+j: show_info(index,gumbi,stoSegleda,"",""))
                button.image = photo
                button.grid(row=i, column=j, sticky="W", padx=15)
                imeBiljke = Label(buttonFrame, text=stoSegleda[i*broj+j][1], font=('Verdana', 15), bg="#F1DBEB", fg="Black")
                imeBiljke.grid(row=i, column=j, sticky="N", padx=0.5, pady=15)
                status = Label(buttonFrame, text=text_status, font=('Verdana', 15), bg=mainColor, fg="White")
                status.grid(row=i, column=j, sticky="e", padx=100, pady=10)
                viseInfo = Button(buttonFrame, image=slika, bg=mainColor, activebackground=mainColor,cursor="hand2", fg="#f0f7e4",command=lambda index=i*broj+j: show_info(index,gumbi,stoSegleda,"",""))
                viseInfo.image = slika
                viseInfo.grid(row=i, column=j, sticky="se", padx=30, pady=20)                

canvas = Canvas(root, bg="#f0f7e4")
canvas.grid(row=1, column=0, sticky="nsew")

scrollbar = Scrollbar(root, orient="vertical", command=canvas.yview)
scrollbar.grid(row=1, column=1, sticky="ns")

canvas.configure(yscrollcommand=scrollbar.set)

buttonFrame = Frame(canvas, bg="#f0f7e4")

canvas.create_window((0, 0), window=buttonFrame, anchor="nw")

buttonFrame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

root.grid_rowconfigure(1, weight=1)

button_images = []
status_images = {
    'dodajte vode': 'images/3.png',
    'prevlažno tlo': 'images/3.png',
    'biljka treba \nmanje svjetla': 'images/3.png',
    'biljka treba svjetla': 'images/3.png',
    'kiseli ph zemlje,\ndodajte supstrat': 'images/2.png',
    'lužnati ph zemlje,\ndodajte supstrat': 'images/2.png',
    'salinitet zemlje visok,\ndodajte supstrat': 'images/2.png',
    'ok': 'images/1.png',
    "":"images/green0.png"
}

update_grid(gumbi,plant_manager.matching_plants)

mainFrame=Frame(root,height=50,bg=mainColor)
mainFrame.grid(row=0, column=0, sticky='ew')
root.grid_columnconfigure(0,weight=1)

canvas.bind_all("<MouseWheel>", lambda event: canvas.yview_scroll(int(-1*(event.delta/120)), "units"))

#sync on hover promjena boje
def gumb(img1,img2):
        ImageB=ImageTk.PhotoImage(Image.open(img1))
        ImageA=ImageTk.PhotoImage(Image.open(img2))

        def on_Enter(e):
            syncButton['image']=ImageB

        def on_leave(e):
            syncButton['image']=ImageA

        syncButton=Button(mainFrame,image=ImageA,bg=mainColor,activebackground=mainColor,fg="Black",command=lambda:[syncClick()])

        syncButton.bind("<Enter>",on_Enter)
        syncButton.bind("<Leave>",on_leave)

        syncButton.place(relx = 0.50,rely = 0.5,anchor = 'center')

gumb("images/sync.png","images/sync.H")

logoButon=Label(mainFrame,image=heading,bg=mainColor,width=300,height=200)
logoButon.place(relx = 0.17,rely = 0.5,anchor = 'e')

stosegleda=Label(mainFrame,text="POSUDE",fg="white",bg=mainColor,font=('Verdana',15))
stosegleda.place(relx = 0.27,rely = 0.5,anchor = 'e')

settingsButon=Button(mainFrame,image=settings,bd=0,bg="#f0f7e4",activebackground="#f0f7e4",width=50,height=50,command=openChange)
settingsButon.place(relx = 0.95,rely = 0.5,anchor = 'w')

switch = Button(mainFrame, image=switchPosude, bd=0, bg="#f0f7e4", activebackground="#f0f7e4", width=100, height=50, command=toggle_switch)
switch.place(relx=0.7, rely=0.5, anchor='w')
syncClick()

#popup----------------------------------------------------------------------------------


changeLogin=Label(root,bg="#6c8046",width=90,height=30)
frameSredina=Label(changeLogin,bg="#ffffff",width=85,height=28)
frameSredina.place(relx = 0.5,rely = 0.5,anchor = 'center')
changeIdentity=Label(frameSredina,fg="Black",bg="#ffffff",font=('Verdana',15),text="Promjena Login podataka")
changeIdentity.place(relx = 0.5,rely = 0.1,anchor = 'center')


oldLetters=Label(frameSredina,text="Old Username:",font=('Verdana',15),bg="#ffffff",fg="black")
oldLetters.place(relx = 0.27,rely = 0.2,anchor = 'e')
usernameOld=Entry(frameSredina,width=20,font=('Verdana',15),bg="white")
usernameOld.place(relx = 0.45,rely = 0.3,anchor = 'e')

newLetters=Label(frameSredina,text="New Username:",font=('Verdana',15),bg="#ffffff",fg="black")
newLetters.place(relx = 0.55,rely = 0.2,anchor = 'w')
usernameNew=Entry(frameSredina,width=20,font=('Verdana',15),bg="white")
usernameNew.place(relx = 0.55,rely = 0.3,anchor = 'w')

oldPas=Label(frameSredina,text="Old Password:",font=('Verdana',15),bg="#ffffff",fg="black")
oldPas.place(relx = 0.26,rely = 0.5,anchor = 'e')
pasOld=Entry(frameSredina,width=20,font=('Verdana',15),bg="white",show="*")
pasOld.place(relx = 0.45,rely = 0.6,anchor = 'e')

eyeButtonOld=Button(pasOld,image=visionOld,bd=0,bg="white",activebackground="white",cursor="hand2",command=showOld)
eyeButtonOld.place(relx = 0.90,rely = 0.50,anchor = 'w')

newPas=Label(frameSredina,text="New Password:",font=('Verdana',15),bg="#ffffff",fg="black")
newPas.place(relx = 0.55,rely = 0.5,anchor = 'w')
pasNew=Entry(frameSredina,width=20,font=('Verdana',15),bg="white",show="*")
pasNew.place(relx = 0.55,rely = 0.6,anchor = 'w')

eyeButtonNew=Button(pasNew,image=visionNew,bd=0,bg="white",activebackground="white",cursor="hand2",command=showNew)
eyeButtonNew.place(relx = 0.90,rely = 0.50,anchor = 'w')

slikaSpremi=ImageB=ImageTk.PhotoImage(Image.open("images/Spremi.png"))
slikaOdustani=ImageTk.PhotoImage(Image.open("images/Odustani.png"))

spremiGumb = Button(frameSredina,image=slikaSpremi, bg="#ffffff", activebackground="#ffffff",cursor="hand2", fg="black",command=lambda:[loginCheck(usernameOld.get(),pasOld.get(),usernameNew.get(),pasNew.get())])
spremiGumb.place(relx = 0.4,rely = 0.8,anchor = 'e')
odustaniGumb = Button(frameSredina, image=slikaOdustani, bg="#ffffff", activebackground="#ffffff",cursor="hand2", fg="black",command=openChange)
odustaniGumb.place(relx = 0.56,rely = 0.8,anchor = 'w')

warningLetters=Label(mainFrame,text="",font=('Verdana',12,'bold'),bg=mainColor,fg="#ffffff")
warningLetters.place(relx = 0.6,rely = 0.5,anchor = 'w')

root.mainloop()