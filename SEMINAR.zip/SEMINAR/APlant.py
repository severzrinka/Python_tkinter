from tkinter import *
from PIL import Image, ImageTk
from tkinter import filedialog
from tkinter import ttk
from matplotlib import pyplot as plt
import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tkinter import messagebox
import os

class APlant:
    def __init__(self, root, slikaStatusa, statusA,slikaBiljke,plantName,update_gumbi,update_Plant,insert_plant,row_count_Plant,index,length,ili,grafdata,update_posuda,get_posuda_by_id,terminator,get_plant_by_all,get_posuda_by_all,get_plant_by_id,swipeIt,stosegleda):
        self.root = root
        self.swipeIt=swipeIt
        self.get_plant_by_id=get_plant_by_id
        self.get_posuda_by_all=get_posuda_by_all
        self.plant_rowCount=length
        self.index=index
        self.grafdata=grafdata
        self.get_plant_by_all=get_plant_by_all
        self.staraSlika=slikaBiljke
        self.terminator=terminator
        self.get_posuda_by_id=get_posuda_by_id
        self.update_gumbi = update_gumbi
        self.update_Plant=update_Plant
        self.insert_plant=insert_plant
        self.update_posuda=update_posuda
        self.ili=ili
        self.stosegleda=stosegleda
        print(self.ili)
        print(self.grafdata)
        if len(self.ili)==8:
            self.mjestoBiljke=self.get_posuda_by_id(self.ili[3])[0][1]
        self.noviId=[]
        self.row_count_Plant=row_count_Plant
        self.podatcisenzora=[]
        if slikaStatusa=="images/green0.png":
            slikaStatusa="images/green.png"
        def validate_input(text):
            return text.isalpha() or text == "" 
        vcmd = (root.register(validate_input), '%P')

        #mjenjanje slike
        def uploadApic():
            filename = filedialog.askopenfilename(initialdir="/", title="Select an image file", filetypes=[("Image files", "*.jpg *.jpeg *.png *.gif")])
            if filename:
                self.staraSlika=filename
                img = Image.open(filename)
                img = img.resize((400, 400), Image.LANCZOS) 
                self.slikaBiljke =ImageTk.PhotoImage(img)
                self.biljka.config(image=self.slikaBiljke)
                identifier=self.ili[0]
                self.update_gumbi(index,self.noviId,identifier,self.biljkaName,filename,freq_var.get(),light_var.get(),temp_var.get(),substrate_var.get())
        #brisanje slike
        def replace():
            self.slikaBiljke = None
            full_path = "images/Nono.png"
            img = Image.open(full_path)
            img = img.resize((400, 400), Image.LANCZOS)
            self.slikaBiljke = ImageTk.PhotoImage(img)
            self.biljka.config(image=self.slikaBiljke)
            identifier=self.ili[0]
            print(identifier)
            self.update_gumbi(index,self.noviId,identifier,self.biljkaName,full_path,freq_var.get(),light_var.get(),temp_var.get(),substrate_var.get())

        #dodavanje nove biljke ili postojeće biljke u posudu
        def addNewPlant(nova,mjesto,x,y,z,m):
            identifier=self.ili[0]
            identifierPosude=self.ili[3]
            print(identifierPosude)
            if(nova==""):
               return messagebox.showerror("Greška","Ime bilke i mjesto biljke mora biti ispunjeno!")
            if self.plantName!="prazna posuda":
                self.plantName = nova
                self.biljkaName.config(text=self.plantName)
                self.update_gumbi(self.index,self.noviId,identifier,self.biljkaName,self.staraSlika,x,y,z,m)
                openChang()
            else:
                self.plantName = nova
                self.biljkaName.config(text=self.plantName)
                update_Plant(nova,self.staraSlika,self.noviId,mjesto,identifierPosude,x,y,z,m)
                self.biljka.config(state="normal")
                self.delete.config(state="normal")
                openChang()

        #dodavanje nove biljke ili izmjenjivanje informacija u postojećoj biljci
        def plantUpdateNew(nova,x,y,z,m):
            identifier=self.ili[0]
            identifierPosude=self.ili[3]
            print(identifierPosude)
            if(nova==""):
               return messagebox.showerror("Greška","Ime bilke mora biti ispunjeno!")
            if self.plantName!="dodaj biljku":
                self.plantName = nova
                self.biljkaName.config(text=self.plantName)
                self.update_gumbi(self.index,self.noviId,identifier,self.biljkaName,self.staraSlika,x,y,z,m)
            else:
                self.plantName = nova
                self.biljkaName.config(text=self.plantName)
                update_Plant(nova,self.staraSlika,self.noviId,None,identifierPosude,x,y,z,m)
                self.biljka.config(state="normal")
                self.delete.config(state="normal")

        #definiranja potreba biljaka i predodređene vrijednosti ako dodaješ novu biljku
        def odustaniBiljke():
            if self.plantName!="dodaj biljku":
                self.plantInputBiljka.delete(0,END)
                self.plantInputBiljka.insert(0, self.plantName)
            else:
                self.plantInputBiljka.insert(0, "")
            if self.stosegleda=="BILJKE":
                freq_var.set(self.ili[3])
                if self.ili[4]=='svjetla':
                    light_var.set(True)
                else:
                    light_var.set(False)
                if self.ili[5]=='toplija':
                    temp_var.set(True)
                else:
                    temp_var.set(False)
                substrate_var.set(self.ili[6])
                if self.plantName=="dodaj biljku":
                    freq_var.set("dnevno")
                    light_var.set(True)
                    temp_var.set(True)
                    substrate_var.set("Pijesak")

        #pražnjenje posude, brisanje biljke
        def delete(sto):
            if self.plantName!="prazna posuda":

                if self.stosegleda!="BILJKE":
                    identifierPosude=self.ili[3]
                    self.terminator(identifierPosude,sto)
                else:
                    identifier=self.ili[0]
                    self.terminator(identifier,sto)
                self.natragButon.invoke()
                self.deleteBiljka.config(state="normal")
            else:
                self.deleteBiljka.config(state=DISABLED)

        #brisanje posude, brisanje biljke
        def deleteAll(sto):
            if self.plantName!="prazna posuda":

                if self.stosegleda!="BILJKE":
                    identifierPosude=self.ili[3]
                    self.terminator(identifierPosude,sto)
                    messagebox.showinfo(
                        "Informacija", "Uspješno obrisana posuda!")
                else:
                    identifier=self.ili[0]
                    self.terminator(identifier,sto)
                    messagebox.showinfo(
                        "Informacija", "Uspješno obrisana biljka!")
                self.natragButon.invoke()
            else:
                self.natragButon.invoke()

        #otvaranje i zatvaranje prozora za promjenu informacija
        def openChang():
            if self.changeLogin.winfo_ismapped():
                self.changeLogin.place_forget()
                self.picContainer.place(relx=0.243, rely=0.594, anchor='e')
                self.mathLibContainer.place(relx=0.5, rely=0.5, anchor='center')
                self.pie_chart_symbol.place(relx=0.8, rely=0.7, anchor='w')
                self.bar_graph_symbol.place(relx=0.8, rely=0.5, anchor='w')
                self.line_graph_symbol.place(relx=0.8, rely=0.3, anchor='w')
                self.izbrišiSve.place(relx=0.9, rely=0.13, anchor='w')
            else:
                self.changeLogin.place(relx=0.5, rely=0.5, anchor='center')
                self.picContainer.place_forget()
                self.mathLibContainer.place_forget()
                self.line_graph_symbol.place_forget()
                self.bar_graph_symbol.place_forget()
                self.pie_chart_symbol.place_forget()
                self.izbrišiSve.place_forget()

        def on_configure(event):
         if self.changeLogin.winfo_ismapped():
            self.changeLogin.place_forget()
            self.changeLogin.place(relx=0.5, rely=0.5, anchor='center')
         else:
             return

        self.root.bind("<Configure>", on_configure)


        self.slikaStatusa =slikaStatusa
        self.statusA = statusA
        self.plantName=plantName
        self.slikaBiljke=Image.open(slikaBiljke)
        self.slikaBiljke = self.slikaBiljke.resize((400, 400), Image.LANCZOS)
        self.slikaBiljke=ImageTk.PhotoImage(self.slikaBiljke)
        self.mainColor = "#92ad5f"
        self.heading = PhotoImage(file="images/PyFloraPosude.png")
        self.settings = PhotoImage(file="images/settings.png")
        
        self.slikaSpremi=ImageB=ImageTk.PhotoImage(Image.open("images/Spremi.png"))
        self.slikaOdustani=ImageTk.PhotoImage(Image.open("images/Odustani.png"))
        self.natrag = PhotoImage(file="images/back.png")
        self.mainFrame = Frame(self.root, height=50, bg=self.mainColor)
        self.mainFrame.grid(row=0, column=0, sticky='ew')
        self.logoButon = Button(self.mainFrame, image=self.heading, bd=0, bg=self.mainColor, activebackground=self.mainColor, relief=SUNKEN, width=300, height=200)
        self.logoButon.place(relx=0.175, rely=0.5, anchor='e')
        self.biljkaName=Label(root,text=self.plantName,font=('Verdana', 15), bg="#f0f7e4", fg="Black")
        self.biljkaName.place(relx=0.5, rely=0.1, anchor='center')
        self.natragButon = Button(self.mainFrame, image=self.natrag,cursor="hand2", bd=0, bg="#f0f7e4", activebackground="#f0f7e4", width=50, height=50,)
        self.natragButon.place(relx=0.045, rely=0.5, anchor='e')

        self.izbrišiSve= Button(self.root,bg="#f1f1f1", activebackground="#f1f1f1",bd=0,font=('Verdana', 45),cursor="hand2",text="\u2672",fg="red",command=lambda:deleteAll(self.ili))
        self.izbrišiSve.place(relx=0.9, rely=0.13, anchor='w')
        if self.stosegleda!="BILJKE":
            Tooltip(self.izbrišiSve, "Izbriši posudu")
        else:
            Tooltip(self.izbrišiSve, "Izbriši biljku")

        #popup----------------------------------------------------------------------------------
        self.changeLogin=Label(root,bg="#6c8046",width=170,height=58)
        self.frameSredina=Label(self.changeLogin,bg="#ffffff",width=165,height=55)
        self.frameSredina.place(relx = 0.5,rely = 0.5,anchor = 'center')
        self.changeIdentity=Label(self.frameSredina,fg="Black",bg="#ffffff",font=('Verdana',15,"bold"),text="Promjena podataka posude",)
        self.changeIdentity.place(relx = 0.5,rely = 0.025,anchor = 'center')
        self.seperator=Button(self.frameSredina,bg="#92ad5f",height=55,relief=SUNKEN,activebackground="#92ad5f")
        self.seperator.place(relx =0.47,rely = 0.7,anchor = 'center')
        self.seperatorTwo=Button(self.frameSredina,bg="#92ad5f",width=170,relief=SUNKEN,activebackground="#92ad5f")
        self.seperatorTwo.place(relx =0.5,rely = 0.18,anchor = 'center')
        self.dodajNovu=Label(self.frameSredina,fg="Black",bg="#ffffff",font=('Verdana',15),text="Dodaj novu biljku ako je prazna posuda \nili promjeni podatke postojeće")
        self.dodajNovu.place(relx = 0.4,rely = 0.24,anchor = 'e')

        if self.stosegleda!="BILJKE":
            self.frame=Label(self.frameSredina,bg="#FFFFFF",width=int((165/2)-5),height=int((55/2)+5))
            self.frame.place(relx = 0.23,rely = 0.62,anchor = 'center')
            freq_frame = Frame(self.frame,pady=20,padx=20)
            freq_frame.pack()

            freq_label =Label(freq_frame, text="potrebe vlažnosti zemlje",font=('Verdana',12))
            freq_label.pack(side="left")

            freq_var = StringVar()
            freq_daily = Radiobutton(freq_frame, text="dnevno",font=('Verdana',12), variable=freq_var, value="dnevno")
            freq_daily.pack(side="left")

            freq_weekly = Radiobutton(freq_frame, text="tjedno",font=('Verdana',12), variable=freq_var, value="tjedno")
            freq_weekly.pack(side="left")

            freq_monthly = Radiobutton(freq_frame, text="mjesečno",font=('Verdana',12), variable=freq_var, value="mjesečno")
            freq_monthly.pack(side="left")

            # da li biljka treba svijetlo ili tamnu
            light_frame = Frame(self.frame,pady=20,padx=20)
            light_frame.pack()

            light_label = Label(light_frame, text="Svjetlo",font=('Verdana',12))
            light_label.pack(side="left")

            light_var = BooleanVar()

            lighter_cb = Checkbutton(light_frame, text="svjetla",font=('Verdana',12), variable=light_var, onvalue=True, offvalue=False)
            lighter_cb.pack(side="left")

            darker_cb = Checkbutton(light_frame, text="tamna",font=('Verdana',12), variable=light_var, onvalue=False, offvalue=True)
            darker_cb.pack(side="left")

            # da li biljka treba toplo ili hladno
            temp_frame = Frame(self.frame,pady=20,padx=20)
            temp_frame.pack()

            temp_label = Label(temp_frame, text="Temperatura",font=('Verdana',12))
            temp_label.pack(side="left")

            temp_var = BooleanVar()

            warmer_cb = Checkbutton(temp_frame, text="toplija",font=('Verdana',12), variable=temp_var, onvalue=True, offvalue=False)
            warmer_cb.pack(side="left")

            colder_cb = Checkbutton(temp_frame, text="hladnija",font=('Verdana',12), variable=temp_var, onvalue=False, offvalue=True)
            colder_cb.pack(side="left")

            # koji supstrat biljka treba
            substrate_frame = Frame(self.frame,pady=20,padx=20)
            substrate_frame.pack()

            substrate_label = Label(substrate_frame, text="Preporuka supstrata",font=('Verdana',12))
            substrate_label.pack(side="left")
            substrate_options = ["Pijesak", "Treset", "Vermikulit", "Perlit", "Kokosova vlakna"]

            substrate_var = StringVar()

            substrate_dropdown = ttk.Combobox(substrate_frame, textvariable=substrate_var, values=substrate_options, state="readonly")
            substrate_dropdown.pack(side="left")
        else:
            self.frame=Label(self.root,width=int((165/2)-5),height=int((55/2)+5))
            self.frame.place(relx = 0.5,rely = 0.4,anchor = 'center')
            freq_frame = Frame(self.frame,pady=20,padx=20)
            freq_frame.pack()

            freq_label =Label(freq_frame, text="potrebe vlažnosti zemlje",font=('Verdana',15))
            freq_label.pack(side="left")

            freq_var = StringVar()
            freq_daily = Radiobutton(freq_frame, text="dnevno",font=('Verdana',15), variable=freq_var, value="dnevno")
            freq_daily.pack(side="left")

            freq_weekly = Radiobutton(freq_frame, text="tjedno",font=('Verdana',15), variable=freq_var, value="tjedno")
            freq_weekly.pack(side="left")

            freq_monthly = Radiobutton(freq_frame, text="mjesečno",font=('Verdana',15), variable=freq_var, value="mjesečno")
            freq_monthly.pack(side="left")

            # da li biljka treba svijetlo ili tamnu
            light_frame = Frame(self.frame,pady=20,padx=20)
            light_frame.pack()

            light_label = Label(light_frame, text="Svjetlo",font=('Verdana',15))
            light_label.pack(side="left")

            light_var = BooleanVar()

            lighter_cb = Checkbutton(light_frame, text="svjetla",font=('Verdana',15), variable=light_var, onvalue=True, offvalue=False)
            lighter_cb.pack(side="left")

            darker_cb = Checkbutton(light_frame, text="tamna",font=('Verdana',15), variable=light_var, onvalue=False, offvalue=True)
            darker_cb.pack(side="left")

            # da li biljka treba toplo ili hladno
            temp_frame = Frame(self.frame,pady=20,padx=20)
            temp_frame.pack()

            temp_label = Label(temp_frame, text="Temperatura",font=('Verdana',15))
            temp_label.pack(side="left")

            temp_var = BooleanVar()

            warmer_cb = Checkbutton(temp_frame, text="toplija",font=('Verdana',15), variable=temp_var, onvalue=True, offvalue=False)
            warmer_cb.pack(side="left")

            colder_cb = Checkbutton(temp_frame, text="hladnija",font=('Verdana',15), variable=temp_var, onvalue=False, offvalue=True)
            colder_cb.pack(side="left")

            # koji supstrat biljka treba
            substrate_frame = Frame(self.frame,pady=20,padx=20)
            substrate_frame.pack()

            substrate_label = Label(substrate_frame, text="Preporuka supstrata",font=('Verdana',15))
            substrate_label.pack(side="left")
            substrate_options = ["Pijesak", "Treset", "Vermikulit", "Perlit", "Kokosova vlakna"]

            substrate_var = StringVar()

            substrate_dropdown = ttk.Combobox(substrate_frame, textvariable=substrate_var, values=substrate_options, state="readonly")
            substrate_dropdown.pack(side="left")
            self.spremiGumbBiljku = Button(self.root,image=self.slikaSpremi, bg="#ffffff", activebackground="#ffffff",cursor="hand2", fg="black",command=lambda:[plantUpdateNew(self.plantInputBiljka.get(),freq_var.get(),light_var.get(),temp_var.get(),substrate_var.get())])
            self.spremiGumbBiljku.place(relx = 0.45,rely = 0.7,anchor = 'e')

            self.plantInputBiljka=Entry(self.root,fg="Black",bg="#ffffff",font=('Verdana',15),width=20,validate="key", validatecommand=vcmd)


            odustaniBiljke()

            self.plantInputBiljka.place(relx = 0.5,rely = 0.2,anchor = 'center')
            self.unosImena=Label(self.root,fg="Black",bg="#f0f7e4",font=('Verdana',15),text="Unesite ime biljke (ISKLJUČIVO SLOVA!)")
            self.unosImena.place(relx = 0.85,rely = 0.2,anchor = 'e')
            self.odustaniGumbBiljka = Button(self.root, image=self.slikaOdustani, bg="#ffffff", activebackground="#ffffff",cursor="hand2", fg="black",command=lambda:[odustaniBiljke()])
            self.odustaniGumbBiljka.place(relx = 0.55,rely = 0.7,anchor = 'w')

        if self.plantName=="prazna posuda":
            freq_var.set("dnevno")
            light_var.set(True)
            temp_var.set(True)
            substrate_var.set("Pijesak")
        else:
            if self.stosegleda!="BILJKE":
                freq_var.set(self.ili[4])
                if self.ili[5]=='svjetla':
                    light_var.set(True)
                else:
                    light_var.set(False)
                if self.ili[6]=='toplija':
                    temp_var.set(True)
                else:
                    temp_var.set(False)
                substrate_var.set(self.ili[7])




        self.dodajPostojecu=Label(self.frameSredina,fg="Black",bg="#ffffff",font=('Verdana',15),text="Zamjeni biljku u posudi \n sa biljkom iz liste biljaka")
        self.dodajPostojecu.place(relx = 0.6,rely = 0.38,anchor = 'w')

        self.frameoptions=Label(self.frameSredina,bg="#ffffff",width=60,height=30)
        self.frameoptions.place(relx = 0.6,rely = 0.6,anchor = 'w')

        self.deleteSelection=Button(self.frameSredina, bg="#ffffff", activebackground="#ffffff",bd=0,font=('Verdana', 45),cursor="hand2",text="\u232B",command=lambda:listbox.selection_clear(0, END))
        self.deleteSelection.place(relx=0.85, rely=0.6, anchor='w')
        Tooltip(self.deleteSelection, "odustani od odabira iz liste biljaka")

        biljkeuposudama=[]
        for i in self.get_posuda_by_all():
            biljkeuposudama.append(self.get_plant_by_id(i[3]))

        numbers = [t[0] for lst in biljkeuposudama for t in lst]

        thisList = [t for t in self.get_plant_by_all() if t[0] not in numbers]  

        options =thisList

        listbox_frame = Frame(self.frameoptions, bg="#ffffff")

        listbox = Listbox(listbox_frame, selectmode=SINGLE, bg="white", font=('Verdana',15))
        for option in options:
            if option == "":
                listbox.insert(END, "")
            else:
                if(option[1]!="dodaj biljku"):
                    listbox.insert(END, "{}, {}".format(option[0],option[1]))

        listbox.config(selectbackground="#f0f7e4", selectforeground="black")

        scrollbar = Scrollbar(listbox_frame, orient=VERTICAL)
        scrollbar.config(command=listbox.yview)
        listbox.config(yscrollcommand=scrollbar.set)

        listbox.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill=Y)
        listbox_frame.pack(side=TOP, fill=BOTH, expand=True)

        selected_option=""


        #funkcija koja dodaje postojeću biljku u posudu
        def print_selected_option(selected_option,mjestoBiljke):
            if(mjestoBiljke==""):
               return messagebox.showerror("Greška","Mjesto biljke mora biti ispunjeno!")
            selected_indices = listbox.curselection()
            print(selected_indices)
            
            for index in selected_indices:
                selected_option = listbox.get(index)
                if selected_option==listbox.get(index):
                    self.swipeIt(self.plantName,mjestoBiljke,self.ili,selected_option)
                    messagebox.showinfo(
                        "Informacija", "Uspješno dodana biljka!")
                    self.natragButon.invoke()

        
        self.spremiGumb = Button(self.frameSredina,image=self.slikaSpremi, bg="#ffffff", activebackground="#ffffff",cursor="hand2", fg="black",command=lambda:[addNewPlant(self.plantInput.get(),self.mjestoInput.get(),freq_var.get(),light_var.get(),temp_var.get(),substrate_var.get())])
        self.spremiGumb.place(relx = 0.2,rely = 0.9,anchor = 'e')

        self.spremiGumbPostoji = Button(self.frameSredina,image=self.slikaSpremi, bg="#ffffff", activebackground="#ffffff",cursor="hand2", fg="black",command=lambda:[print_selected_option(selected_option,self.mjestoInput.get())])
        self.spremiGumbPostoji.place(relx = 0.5,rely = 0.9,anchor = 'w')


        self.plant=Label(self.frameSredina,fg="Black",bg="#ffffff",font=('Verdana',15),text="Ime biljke (ISKLJUČIVO SLOVA!)")
        self.plant.place(relx = 0.3,rely = 0.32,anchor = 'e')
        self.plantInput=Entry(self.frameSredina,fg="Black",bg="#ffffff",font=('Verdana',15),width=20,validate="key", validatecommand=vcmd)

        if self.plantName!="prazna posuda":
            self.plantInput.insert(0, self.plantName)
        else:
            self.plantInput.insert(0, "")


        self.plantInput.place(relx = 0.25,rely = 0.38,anchor = 'e')
        self.mjesto=Label(self.frameSredina,fg="Black",bg="#ffffff",font=('Verdana',15),text="Lokacija posude")
        self.mjesto.place(relx = 0.5,rely = 0.08,anchor = 'center')
        self.mjestoInput=Entry(self.frameSredina,fg="Black",bg="#ffffff",font=('Verdana',15),width=20)
        if len(self.ili)==8:
            self.mjestoInput.insert(0, self.mjestoBiljke)
        self.mjestoInput.place(relx = 0.5,rely = 0.13,anchor = 'center')


        self.odustaniGumb = Button(self.frameSredina, image=self.slikaOdustani, bg="#ffffff", activebackground="#ffffff",cursor="hand2", fg="black",command=lambda:[openChang()])
        self.odustaniGumb.place(relx = 0.8,rely = 0.9,anchor = 'w')
        self.deleteBiljka=Button(self.frameSredina, bg="#ffffff", activebackground="#ffffff",bd=0,font=('Verdana', 45),cursor="hand2",text="\u2717",command=lambda: delete(self.ili))
        self.deleteBiljka.place(relx=0.93, rely=0.05, anchor='w')
        Tooltip(self.deleteBiljka, "izpraznite posudu")

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        self.root.grid_columnconfigure(0, weight=1)
        self.picContainer=Frame(self.root, height=971,width=410, bg="#f0f7e4")
        self.picContainer.place(relx=0.243, rely=0.594, anchor='e')
        if self.stosegleda!="BILJKE":
            self.settingsButon = Button(self.mainFrame, image=self.settings, bd=0, bg="#f0f7e4", activebackground="#f0f7e4", width=50, height=50,command=lambda:[openChang()])
            self.settingsButon.place(relx=0.95, rely=0.5, anchor='w')
            self.line_graph_symbol=Button(self.root,text="\U0001F4C8", font=('Verdana', 50), bg="#f1f1f1", activebackground="#f1f1f1",relief=FLAT,command=lambda:[show_line_graphs(self,self.grafdata)])
            self.line_graph_symbol.place(relx=0.8, rely=0.3, anchor='w')
            Tooltip(self.line_graph_symbol, "linijski grafikon")
            self.bar_graph_symbol=Button(self.root,text="\U0001F4CA", font=('Verdana', 50), bg="#f1f1f1", activebackground="#f1f1f1",relief=FLAT,command=lambda:[show_bars_graphs(self,self.grafdata)])
            self.bar_graph_symbol.place(relx=0.8, rely=0.5, anchor='w')
            Tooltip(self.bar_graph_symbol, "stupčasti grafikon") 
            self.pie_chart_symbol=Button(self.root,text="\u25EF", font=('Verdana', 50), bg="#f1f1f1", activebackground="#f1f1f1",relief=FLAT,command=lambda:[show_pie_chart(self,self.grafdata)])
            self.pie_chart_symbol.place(relx=0.8, rely=0.7, anchor='w')
            Tooltip(self.bar_graph_symbol, "kružni graf") 
            self.mathLibContainer=Frame(self.root, height=10,width=10, bg="#f1f1f1")
            self.mathLibContainer.place(relx=0.5, rely=0.5, anchor='center')
            def show_line_graphs(self,data):
                time = []
                new_soil = [0]
                new_ph = [0] 
                new_salt = [0] 
                new_light = [0]
                for tuple_item in data:
                    new_soil.append(tuple_item[1])
                    new_ph.append(tuple_item[2])
                    new_salt.append(tuple_item[3])
                    new_light.append(tuple_item[4])
                for i in range(1, len(new_soil)+1):
                    time.append(int(i))
                for widget in self.mathLibContainer.winfo_children():
                    widget.destroy()
                plt.close('all')
                fig = plt.figure(figsize=(8, 6), facecolor="#f1f1f1")
                plt.plot(time, new_soil, label="Potrebe vode")
                plt.plot(time, new_ph, label="PH vrijednost")
                plt.plot(time, new_salt, label="Salinitet zemlje")
                plt.plot(time, new_light, label="Potrebe svijetla")
                plt.xlabel("Vrijeme")
                plt.ylabel("Vrijednosti senzora")
                plt.title("Graf s linijama")
                plt.legend()

                canvas = FigureCanvasTkAgg(fig, master=self.mathLibContainer)
                canvas.draw()
                canvas.get_tk_widget().pack()
            def show_bars_graphs(self,data):
                time = []
                new_soil = [0]
                new_ph = [0] 
                new_salt = [0] 
                new_light = [0]
                for tuple_item in data:
                    new_soil.append(tuple_item[1])
                    new_ph.append(tuple_item[2])
                    new_salt.append(tuple_item[3])
                    new_light.append(tuple_item[4])
                for i in range(1, len(new_soil)+1):
                    time.append(int(i))
                for widget in self.mathLibContainer.winfo_children():
                    widget.destroy()
                plt.close('all')

                fig, ax = plt.subplots(figsize=(8, 6), facecolor="#f1f1f1")

                bar_width = 0.1
                bar_positions = np.arange(len(time))

                ax.bar(bar_positions - 2 * bar_width, new_soil, width=bar_width, label="Potrebe vode")
                ax.bar(bar_positions - bar_width, new_ph, width=bar_width, label="PH vrijednost")
                ax.bar(bar_positions, new_salt, width=bar_width, label="Salinitet zemlje")
                ax.bar(bar_positions + bar_width, new_light, width=bar_width, label="Potrebe svijetla")

                ax.set_xlabel("Vrijeme")
                ax.set_ylabel("Vrijednosti senzora")
                ax.set_title("Graf sa stupovima")
                ax.set_xticks(bar_positions)
                ax.set_xticklabels(time)


                ax.legend()

                canvas = FigureCanvasTkAgg(fig, master=self.mathLibContainer)
                canvas.draw()
                canvas.get_tk_widget().pack()

            def show_pie_chart(self,data):
                new_soil = [0]
                new_ph = [0] 
                new_salt = [0] 
                new_light = [0]
                for tuple_item in data:
                    new_soil.append(tuple_item[1])
                    new_ph.append(tuple_item[2])
                    new_salt.append(tuple_item[3])
                    new_light.append(tuple_item[4])
                labels = ['Potrebe vode', 'PH vrijednost', 'Salinitet zemlje', 'Potrebe svijetla']
                data = [sum(new_soil), sum(new_ph), sum(new_salt), sum(new_light)]
                for widget in self.mathLibContainer.winfo_children():
                    widget.destroy()
                plt.close('all')
                fig, ax = plt.subplots(figsize=(8, 6), facecolor="#f1f1f1")

                ax.pie(data, labels=labels, autopct='%1.1f%%')
                ax.axis('equal')
                ax.set_title('Kružni graf')

                canvas = FigureCanvasTkAgg(fig, master=self.mathLibContainer)
                canvas.draw()
                canvas.get_tk_widget().pack()

        
        
        self.stat = Button(self.picContainer, image=self.slikaStatusa, bd=0, bg="#f0f7e4", activebackground="#f0f7e4", relief=SUNKEN, width=200, height=200)
        self.stat.place(relx=0.2, rely=0.65, anchor='w')
        if self.plantName!="prazna posuda":
            self.slikaTekst="kliknite na sliku kako \n bi je promjenili."
            self.pravo=True
            
            
        else:
            self.slikaTekst=" \n Dobiti ćete prava \n promijeniti sliku nakon što \n unesete sve podatke \n za dodavanje nove biljke!"
            self.pravo=False
            
        self.promjenaS =Label(self.picContainer,text=self.slikaTekst, font=('Verdana', 14), bg="#f0f7e4", fg="Black")
        self.promjenaS.place(relx=0.42, rely=0.15, anchor='s')
        self.biljka = Button(self.picContainer, image=self.slikaBiljke, bg="white", activebackground="white",cursor="hand2", width=400, height=400,command=lambda:uploadApic())
        self.biljka.place(relx=0, rely=0.37, anchor='w')
        self.delete=Button(self.picContainer, bg="#f0f7e4", activebackground="#f0f7e4",bd=0,font=('Verdana', 45),cursor="hand2",text="\u2717",command=lambda:[replace()])
        self.delete.place(relx=0.75, rely=0.075, anchor='w')

        if self.pravo==True:
            self.biljka.config(command=uploadApic)
            self.delete.config(command=replace)
            self.deleteBiljka.config(state="normal")
        else:
            self.biljka.config(state=DISABLED)
            self.delete.config(state=DISABLED)
            self.deleteBiljka.config(state=DISABLED)

        Tooltip(self.delete, "obrišite sliku")
        self.statusT =Label(self.picContainer,text=statusA, font=('Verdana', 13), bg="#f0f7e4", fg="Black")
        self.statusT.place(relx=0.7, rely=0.78, anchor='e')
class Tooltip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tooltip = None
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.leave)

    def enter(self, event=None):
        self.tooltip = Toplevel()
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.wm_geometry("+%d+%d" % (x, y))
        label = Label(self.tooltip, text=self.text, justify='left', background='#ffffe0', relief='solid', borderwidth=1, font=("Arial", "10", "normal"))
        label.pack(ipadx=1)

    def leave(self, event=None):
        if self.tooltip:
            self.tooltip.destroy()